# AeroX AIO V2 — Discord Bot

## Overview
A feature-rich Discord All-In-One bot built with Discord.js v14. Includes advanced moderation, anti-nuke protection, music streaming (Lavalink/Kazagumo), AI-powered chat (Groq/Llama), sticky messages, giveaways, auto-roles, and more.

## Tech Stack
- **Runtime**: Node.js 20
- **Framework**: Discord.js v14
- **Databases**: QuickDB (SQLite) for configs, MongoDB (Mongoose) for giveaways
- **Music**: Kazagumo + Shoukaku (Lavalink wrapper)
- **AI**: Groq SDK (llama-3.3-70b-versatile)
- **Eval/Debug**: Dokdo

## Project Structure
- `index.js` — Entry point, bot login, sticky messages, 24/7 voice, database setup
- `rabbit/RabbitClient.js` — Custom Discord Client class
- `handler/` — Loaders for commands, slash commands, music, client utils
- `commands/` — Prefix commands by category (antinuke, moderation, utility, etc.)
- `slashCommands/` — Slash commands (ai, music, moderation, tickets, welcome)
- `events/` — Event listeners (anti-nuke system, automod, media channels, etc.)
- `database/` — SQLite database files
- `config.json` — Bot token, MongoDB URI, webhook URLs, Groq API key
- `dev.json` — Owner IDs and access lists

## Configuration
- `config.token` — Discord bot token
- `config.mongo` — MongoDB connection string
- `config.groqApiKey` — Groq API key for AI chat feature
- `config.webhook` / `config.joinwebhook` — Optional Discord webhook URLs for logging
- `config.webid` / `config.webtoken` — Optional webhook ID/token for anti-nuke alerts

## Running
```
npm start
```

## Bugs Fixed
1. `events/messageCreate.js` — `mediaBypass` variable was undefined (added as empty array)
2. `events/antiChannel.js` — Used `channel.guild.id` inside `handleChannelUpdate` where param is `newChannel`; fixed + added `|| []` null-safety to `extraOwner`
3. `events/antiGuild.js` — Used `guild.ownerId` where `guild` was undefined (should be `newGuild`); fixed + null-safety
4. `events/antiRole.js` — `sendWebhookError` was called but never defined; added the function
5. `events/antiSticker.js` — Multiple bugs: `newRole` referenced instead of `sticker`, variable shadowing of `sticker` param; rewrote entirely
6. `events/antiWebhook.js` — Variable self-shadowing `const webhook = webhook.webhook`; fixed auto-recovery logic
7. All anti-nuke files — `WebhookClient` created unconditionally with empty strings, causing crash on startup; made conditional
8. `events/clientErrors.js` — Same WebhookClient empty-URL crash; made conditional
9. `events/guildJoinLeaveSystem.js` — Same WebhookClient empty-URL crash; made conditional + guarded `.send()` calls
