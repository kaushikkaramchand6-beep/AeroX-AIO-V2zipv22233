const { ownerIDS } = require('../dev.json');
const client = require('../index.js');
const { WebhookClient, AuditLogEvent, Events } = require('discord.js');
const config  = require('../config.json');

const webhookClient = config.webid && config.webtoken ? new WebhookClient({ id: config.webid, token: config.webtoken }) : null;

async function handleRateLimit() {
  await new Promise((resolve) => setTimeout(resolve, 5000));
}

async function handleStickerCreate(sticker) {
  try {
    const auditLogs = await sticker.guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.StickerCreate });
    const logs = auditLogs.entries.first();

    if (!logs) return;

    const { executor } = logs;

    const whitelistData = await client.db.get(`${sticker.guild.id}_wl`);
    const trusted = whitelistData?.whitelisted.includes(executor.id);
    const extraOwner = (await client.db11.get(`${sticker.guild.id}_eo.extraownerlist`)) || [];
    const antinuke = await client.db.get(`${sticker.guild.id}_antistickercreate`);
    const autorecovery = await client.db.get(`${sticker.guild.id}_autorecovery`);

    if (
      executor.id === sticker.guild.ownerId ||
      ownerIDS.includes(executor.id) ||
      executor.id === client.user.id ||
      extraOwner.includes(executor.id) ||
      antinuke !== true ||
      trusted === true
    ) return;

    if (!sticker.guild.members.me.permissions.has('ManageEmojisAndStickers')) {
      sendWebhookError('Bot lacks necessary permissions for sticker create actions.');
      return;
    }

    if (!sticker.guild.members.me.permissions.has('BanMembers')) {
      sendWebhookError('Bot lacks necessary permissions for ban actions.');
      return;
    }

    const executorMember = await sticker.guild.members.fetch(executor.id).catch(() => null);
    if (!executorMember) return;

    const botMember = sticker.guild.members.me;
    if (executorMember.roles.highest.comparePositionTo(botMember.roles.highest) >= 0) return;

    await sticker.guild.members.ban(executorMember.id, { reason: 'Sticker Create | Not Whitelisted' });

    if (autorecovery === true) {
      await sticker.delete().catch(() => {});
    }
  } catch (err) {
    if (err.code === 429) {
      await handleRateLimit();
      return;
    }
    sendWebhookError(err);
  }
}

async function handleStickerDelete(sticker) {
  try {
    const auditLogs = await sticker.guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.StickerDelete });
    const logs = auditLogs.entries.first();

    if (!logs) return;

    const { executor } = logs;

    const antinuke = await client.db.get(`${sticker.guild.id}_antistickerdelete`);
    const whitelistData = await client.db.get(`${sticker.guild.id}_wl`);
    const trusted = whitelistData?.whitelisted.includes(executor.id);
    const extraOwner = (await client.db11.get(`${sticker.guild.id}_eo.extraownerlist`)) || [];

    if (
      executor.id === sticker.guild.ownerId ||
      ownerIDS.includes(executor.id) ||
      executor.id === client.user.id ||
      extraOwner.includes(executor.id) ||
      antinuke !== true ||
      trusted === true
    ) return;

    if (!sticker.guild.members.me.permissions.has('ManageEmojisAndStickers')) {
      sendWebhookError('Bot lacks necessary permissions for sticker delete actions.');
      return;
    }

    if (!sticker.guild.members.me.permissions.has('BanMembers')) {
      sendWebhookError('Bot lacks necessary permissions for ban actions.');
      return;
    }

    const executorMember = await sticker.guild.members.fetch(executor.id).catch(() => null);
    if (!executorMember) return;

    const botMember = sticker.guild.members.me;
    if (executorMember.roles.highest.comparePositionTo(botMember.roles.highest) >= 0) return;

    await sticker.guild.members.ban(executorMember.id, { reason: 'Sticker Delete | Not Whitelisted' });

  } catch (err) {
    if (err.code === 429) {
      await handleRateLimit();
      return;
    }
    sendWebhookError(err);
  }
}

async function handleStickerUpdate(oldSticker, newSticker) {
  try {
    const auditLogs = await newSticker.guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.StickerUpdate });
    const logs = auditLogs.entries.first();

    if (!logs) return;

    const { executor } = logs;

    const antinuke = await client.db.get(`${newSticker.guild.id}_antistickerupdate`);
    const whitelistData = await client.db.get(`${newSticker.guild.id}_wl`);
    const extraOwner = (await client.db11.get(`${newSticker.guild.id}_eo.extraownerlist`)) || [];
    const trusted = whitelistData?.whitelisted.includes(executor.id);
    const autorecovery = await client.db.get(`${newSticker.guild.id}_autorecovery`);

    if (
      executor.id === newSticker.guild.ownerId ||
      ownerIDS.includes(executor.id) ||
      executor.id === client.user.id ||
      extraOwner.includes(executor.id) ||
      antinuke !== true ||
      trusted === true
    ) return;

    if (!newSticker.guild.members.me.permissions.has('ManageEmojisAndStickers')) {
      sendWebhookError('Bot lacks necessary permissions for sticker update actions.');
      return;
    }

    if (!newSticker.guild.members.me.permissions.has('BanMembers')) {
      sendWebhookError('Bot lacks necessary permissions for ban actions.');
      return;
    }

    const executorMember = await newSticker.guild.members.fetch(executor.id).catch(() => null);
    if (!executorMember) return;

    const botMember = newSticker.guild.members.me;
    if (executorMember.roles.highest.comparePositionTo(botMember.roles.highest) >= 0) return;

    await newSticker.guild.members.ban(executorMember.id, { reason: 'Sticker Update | Not Whitelisted' });

    if (autorecovery === true) {
      await newSticker.edit({ name: oldSticker.name }).catch(() => {});
    }
  } catch (err) {
    sendWebhookError(err);
  }
}

function sendWebhookError(error) {
  if (webhookClient) webhookClient.send(error).catch(() => {});
}

client.on(Events.GuildStickerCreate, async (sticker) => handleStickerCreate(sticker));
client.on(Events.GuildStickerDelete, async (sticker) => handleStickerDelete(sticker));
client.on(Events.GuildStickerUpdate, async (oldSticker, newSticker) => handleStickerUpdate(oldSticker, newSticker));
